#include <iostream>
#include <string.h>

#include "pool.h"

using namespace std;

#define SIZE_OF_ARR 10
#define MAX_NAME_LEN 50


void checkPage10bytesInsert10Ints();
void checkPage2BytesInsertDouble();
/*------------------------------------------------------------------------------------*/

int main() 
{
	checkPage10bytesInsert10Ints();
	
	checkPage2BytesInsertDouble();
	
	return 0;
}

/*------------------------------------------------------------------------------------*/

void checkPage10bytesInsert10Ints()
{
	int i;
	//MemPool_t pool(10);	 //10 bytes per page
	MemPool_t pool;
	int intToWrite[SIZE_OF_ARR] ;
	int intToRead;

	for(i=0; i< SIZE_OF_ARR; i++){
		intToWrite[i] = i;
	}

	for(i=0; i< SIZE_OF_ARR; i++){
		pool.write( &intToWrite[i] , sizeof(int));	
		pool.read(&intToRead ,sizeof(int) , sizeof(int)*i );	
		cout << endl << "num is : " << intToRead << endl << endl;
	}

}

/*------------------------------------------------------------------------------------*/

void checkPage2BytesInsertDouble()
{
	//MemPool_t pool(4);	 //2 bytes per page
	MemPool_t pool;	
	double dToWrite = 777.555 ;
	double dToRead;

	pool.setDefaultPageCapcity(2);

	pool.write( &dToWrite , sizeof(double));	
	pool.read(&dToRead ,sizeof(double) , 0);	
	cout << endl << "num is : " << dToRead << endl << endl;

}

/*------------------------------------------------------------------------------------*/

