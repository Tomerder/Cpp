#include <string.h>
#include <iostream>

#include "pool.h"

using namespace std;


/*--------------------------------------------------------------------------------*/

//private and will not be used!!!!!!!!!!!!!
MemPool_t& MemPool_t::operator=(const MemPool_t& _mem)   //operator= 
{return *this;}

//private and will not be used!!!!!!!!!!!!!
MemPool_t::MemPool_t(const MemPool_t& _mem)
{}

/*--------------------------------------------------------------------------------*/

MemPool_t::MemPool_t()    //ctor
{
	//m_pagesCapacity = DEFAULT_INITIAL_PAGE_CAPACITY;	
	PageCreate();
}

/*
MemPool_t::MemPool_t(int _pagesCapacity)    //ctor
{
	//m_pagesCapacity = _pagesCapacity;	 
	PageCreate();
}
*/

MemPage_t* MemPool_t::PageCreate()  //create first page in list
{
	//MemPage_t* page = new MemPage_t(m_pagesCapacity);
	MemPage_t* page = new MemPage_t();
	
	m_pages.push_back(page);

	return page;
}

/*--------------------------------------------------------------------------------*/

MemPool_t::~MemPool_t()    //dtor
{   		  	
	while (!m_pages.empty())
    {
		delete m_pages.front();
		m_pages.pop_front();
    } 
}

/*--------------------------------------------------------------------------------*/

MemPage_t* MemPool_t::GetPageOfPos(int _pos ,int* _posCounter)
{
	MemPage_t* memPage =0;
	bool wasPageFound = false;
	int pageCapacity;

	list<MemPage_t*>::iterator it;
	for(it = m_pages.begin(); it != m_pages.end() ; it++){ //go through list of pages
		memPage = *it;
		pageCapacity =  memPage->getCapacity();
		if(*_posCounter + pageCapacity <= _pos){ //advance to next page in pool 
			*_posCounter += pageCapacity;
		}else{
			wasPageFound = true;
			break;
		}
	}	
	
	if(!wasPageFound){
		memPage = 0;
	}

	return memPage;
}

/*--------------------------------------------------------------------------------*/	


bool MemPool_t::write(const void* _dataToWrite, int _len) 
{
	int posCounter = 0;		
	int pagePosToWrite;
	int pageCapacity;
	int curPos = getCurPos();
	int lenLeftToWrite = _len;	
	MemPage_t* memPage=0;
	
	memPage = GetPageOfPos(curPos, &posCounter);   // posCounter= position of page start
		
	if(!memPage){   //need to create new page 
		memPage = PageCreate();
	}
		
	pageCapacity = memPage->getCapacity();
	pagePosToWrite  =  curPos - posCounter;  //will be 0 if new page was created                          
	
	while(lenLeftToWrite > 0){
		if(pagePosToWrite + lenLeftToWrite > pageCapacity ){  //check if there is enough space on this page
			//write on this page and on the next
			int bytesToWrtCurPage = pageCapacity - pagePosToWrite;		
			memPage->write(_dataToWrite + (_len - lenLeftToWrite), bytesToWrtCurPage, pagePosToWrite);  //write on cur page
			int bytesToWrtNxtPage = lenLeftToWrite - bytesToWrtCurPage;;			
			lenLeftToWrite -= bytesToWrtCurPage;
			//create next page
			memPage = PageCreate(); 						
			if(pageCapacity > bytesToWrtNxtPage ){
				memPage->write(_dataToWrite + (_len - lenLeftToWrite) , bytesToWrtNxtPage, 0);  //write on next page	   
				lenLeftToWrite -= bytesToWrtNxtPage;
				break;
			}else{ 
				//next page is smaller then bytesToWrtNxtPage  - e.g: 20 bytes when page size is 4
				memPage->write(_dataToWrite + (_len - lenLeftToWrite) , pageCapacity, 0);
				lenLeftToWrite -= pageCapacity;
				memPage = PageCreate(); //next page to write on 
				pagePosToWrite = 0;
				pageCapacity = memPage->getCapacity();
				continue;
			}		
		}else{  //enough space on this page
			memPage->write(_dataToWrite + (_len - lenLeftToWrite), _len, pagePosToWrite);
			lenLeftToWrite -= _len;
			break;
		} 
	}
	
	int curSize = getCurSize();
	if ( curSize < curPos + _len){	
		setCurSize( curPos + _len );  // set new size
	}	

	setCurPos(curPos + _len );  // set new pos
	
	return true;
}



bool MemPool_t::write(const void* _dataToWrite, int _len, int _pos) 
{
	if( _pos <= getCurSize() ) {
		setCurPos(_pos);
		write(_dataToWrite, _len); 
		return true;
	}else{
		return false;
	}	
}


/*--------------------------------------------------------------------------------*/	

bool MemPool_t::read(void* _dataToRead, int _len )  
{
	read(_dataToRead,  _len, getCurPos() ) ;
	return true; 
}



bool MemPool_t::read(void* _dataToRead, int _len, int _pos) 
{
	int posCounter = 0;	
	int pageCapacity;	
	int pagePosToRead;
	int lenLeftToread = _len;	
	MemPage_t* memPage =0;
	void* buff = 0;	
	
	//check if read from legal position 
	if( _pos + _len > getCurSize() ){
		return false;
	}

	buff = new char[_len]; 
	memPage = GetPageOfPos(_pos, &posCounter);   // posCounter= position of page start
	
	if(memPage){	//will always be true because pos is legal - protection 
		pageCapacity = memPage->getCapacity();
		pagePosToRead  =  _pos - posCounter;                           
		
		while( lenLeftToread > 0){
			if(pagePosToRead + lenLeftToread > pageCapacity ){  //check to see if there is enough space on this page	
				//read from this page and from the next	
				int bytesToReadCurPage = pageCapacity - pagePosToRead;
				int bytesToReadNxtPage = lenLeftToread - bytesToReadCurPage;
				//read from cur page	
				memPage->read(buff, bytesToReadCurPage, pagePosToRead);
				memcpy(_dataToRead + (_len - lenLeftToread) , buff , bytesToReadCurPage);
				lenLeftToread -= bytesToReadCurPage;  	
				memPage = getNextPage(memPage);
				pageCapacity = memPage->getCapacity();
				if(bytesToReadNxtPage <= pageCapacity){
					//read from next page	   
					memPage->read(buff, bytesToReadNxtPage, 0);
					memcpy(_dataToRead + (_len - lenLeftToread), buff, bytesToReadNxtPage);
					lenLeftToread -= bytesToReadNxtPage;
					break;  	 
				}else{
					//read from next page and continue to next one	   
					memPage->read(buff, pageCapacity, 0);
					memcpy(_dataToRead + (_len - lenLeftToread), buff, pageCapacity);
					lenLeftToread -= pageCapacity;
					memPage = getNextPage(memPage);
					pagePosToRead = 0;
					pageCapacity = memPage->getCapacity();
					continue; 
				}					
			}else{  //all data to read is on this page
				memPage->read(_dataToRead + (_len - lenLeftToread), lenLeftToread, pagePosToRead);
				lenLeftToread -= _len;
				break;
			} 
		}
	}
	
	setCurPos(_pos + _len );  // set new pos
	
	delete[] buff; 
		
	return true;
	
} 



/*--------------------------------------------------------------------------------*/	


MemPage_t* MemPool_t::getNextPage(MemPage_t* _memPage){
	list<MemPage_t*>::iterator it = m_pages.begin();
	
	for(; *it !=_memPage ; it++);

	return *(++it); 
}


/*--------------------------------------------------------------------------------*/	









	
	

