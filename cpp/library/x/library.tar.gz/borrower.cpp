#include <string.h>
#include <iostream>

#include "borrower.h"

using namespace std;


/*static member initialization*/	
unsigned int Borrower::m_count = 1;		

