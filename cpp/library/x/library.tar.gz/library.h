/**************************************************************************************
    Author : Tomer Dery
    Creation date :      16.01.14
    Date last modified : 16.01.14 
    Description : Library 
***************************************************************************************/
#ifndef __LIBRARY_H__
#define __LIBRARY_H__

#include <map>
#include <string>
using namespace std;

#include "libraryBook.h"
#include "borrower.h"

typedef struct BookCount{
	unsigned int m_count;	
	unsigned int m_countOut;	
}BookCount;

typedef map < unsigned int, Borrower* >::iterator ItrBorrwer;
typedef map < unsigned int, Borrower* >::const_iterator CItrBorrwer;
typedef map < unsigned int, LibraryBook* >::iterator ItrLibBook;
typedef map < unsigned int, LibraryBook* >::const_iterator CItrLibBook;
typedef map < unsigned int, BookCount* >::iterator ItrBookCount;
typedef multimap < unsigned int, LibraryBook* >::iterator ItrMMbookLibBook;

class Library{ 

private: 	
	/*borrower maps*/
	map < unsigned int, Borrower* > m_custMap;  /*custnum , Borrower*   */   /*1*/
	map < unsigned int, Borrower* > m_custMapId;  /*id , Borrower*   */      /*2*/
	
	/*callnum , LibraryBook*   */
	map < unsigned int, LibraryBook* > m_libBookMap;  /*3*/
	
	/*isbn , BookCount */
	map < unsigned int, BookCount* > m_bookCountMap;  /*4*/
	
	/*isbn , LibraryBook* */
	multimap < unsigned int, LibraryBook* > m_bookLibBookMMap;  /*5*/
	
	/*isbn , Borrower*   */
	multimap < unsigned int, Borrower* > m_waitingList;  /*6*/
	
	/*private methods*/
	void IncLibBookCount(const LibraryBook* _book);
	void DecLibBookCount(const LibraryBook* _book);
	
	ItrBorrwer SearchBorrowerImp(unsigned int _custNum);
	ItrBorrwer SearchBorrowerByIdImp(unsigned int _id);
	
	ItrLibBook SearchLibBookImp(unsigned int _callNum);
		
	/*not allowed*/
	Library(const Library& _lib);
	Library& operator=(const Library& _lib);		

public: 	
	Library() {}
		
	virtual ~Library();
	/*
	map < unsigned int, Borrower* > getCustMap() {return m_custMap;}
	map < unsigned int, LibraryBook* >  getLibBookMap() {return m_libBookMap;}
	
	map < unsigned int, BookCount* > getBookCountMap() {return m_bookCountMap;}
	
	multimap < unsigned int, LibraryBook* > getBookLibBookMMap() {return m_bookLibBookMMap;}
	multimap < unsigned int, Borrower* > getWaitingList() {return m_waitingList;}
	*/
	unsigned int AddBorrower(const Person& _person);  /*returns custNum , if failed 0 */
	bool RemoveBorrower(unsigned int _custNum);
	Borrower* SearchBorrower(unsigned int _id);
	
	unsigned int AddLibBook(const Book& _book);       /*returns callNumber , if failed 0 */
	bool RemoveLibBook(unsigned int _callNum);
	LibraryBook* SearchLibBook(unsigned int _callNum);
	
	bool BorrowBook(unsigned int _custId, unsigned int _isbn);
	bool ReturnBook(unsigned int _custId, unsigned int _callNum);
	
	
	void PrintCusts() const;
	void PrintLibBooks() const;
	
	
};
	
#endif /*__LIBRARY_H__*/


