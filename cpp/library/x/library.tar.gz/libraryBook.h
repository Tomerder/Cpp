/**************************************************************************************
    Author : Tomer Dery
    Creation date :      16.01.14
    Date last modified : 16.01.14 
    Description : Library 
***************************************************************************************/
#ifndef __LIBRARY_BOOK_H__
#define __LIBRARY_BOOK_H__

#include "book.h"
/*#include "borrower.h"*/
class Borrower;

typedef enum{START_LBS=0, AVAILABLE=0 ,OUT , MAINTENANCE , END_LBS} LIBRARY_BOOK_STATUS;

class LibraryBook : public Book{ 

private: 	
	const unsigned int m_callNum;
	static unsigned int m_count;
	LIBRARY_BOOK_STATUS m_status; 
	Borrower* m_curBorrower;
	
	/*not allowed*/
	LibraryBook(const LibraryBook& _book);	
	LibraryBook& operator=(const LibraryBook& _book);	

public: 		
	LibraryBook(const Book& _book) :
		    Book(_book) ,
		    m_callNum(m_count++) , m_status(AVAILABLE)   , m_curBorrower(0)  {}
		
	virtual ~LibraryBook() { /*--m_count;*/ }	
	
	unsigned int getCallNum() const {return m_callNum;}
	static unsigned int getCount() {return m_count;}
	LIBRARY_BOOK_STATUS getStatus() const {return m_status;}

	void setStatus(LIBRARY_BOOK_STATUS _status) {m_status = _status;} 
	
	virtual void Print() const { Book::Print(); cout << "LIB BOOK- callNum: " <<  m_callNum << " , status: " <<  m_status << endl ;  } 
};

#endif /*__LIBRARY_BOOK_H__*/


