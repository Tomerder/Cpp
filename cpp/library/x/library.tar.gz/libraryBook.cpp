#include <string.h>
#include <iostream>

#include "libraryBook.h"

using namespace std;


/*static member initialization*/	
unsigned int LibraryBook::m_count = 1;		

