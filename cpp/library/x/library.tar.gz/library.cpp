#include <string.h>
#include <iostream>
#include <algorithm>

#include "library.h"

using namespace std;


/*------------------------------------------------------------------------------------*/

Library::~Library() 
{
	/*TODO - delete all items on every stl*/
}	

/*------------------------------------------------------------------------------------*/

unsigned int Library::AddBorrower(const Person& _person)
{
	Borrower* newBorrower = new Borrower(_person);
	
	/*add to cust map*/
	unsigned int custNum =  newBorrower->getCustNum();
	m_custMap[ custNum ] = newBorrower; /*1*/
	m_custMapId[ newBorrower->getId() ] = newBorrower;   /*2*/

	return custNum;
}

/*------------------------------------------------------------------------------------*/

bool Library::RemoveBorrower(unsigned int _custNum)
{
	/*check if exists*/
	ItrBorrwer itrBorrwer = SearchBorrowerImp(_custNum);
	if(itrBorrwer == m_custMap.end()){
		return false;
	}
	
	/*remove from all maps*/
	Borrower* borrower = itrBorrwer->second;
	m_custMap.erase(itrBorrwer);     /*1*/
	m_custMapId.erase( borrower->getId() ); /*2*/
	
	delete(borrower);

	return true;
}

/*------------------------------------------------------------------------------------*/

unsigned int Library::AddLibBook(const Book& _book)
{
	LibraryBook* newlibBook = new LibraryBook(_book);
	
	/*add to libBook map*/
	unsigned int callNum = newlibBook->getCallNum();
	m_libBookMap[ callNum ] = newlibBook;  /*3*/
	
	/*add to book count map*/
	IncLibBookCount(newlibBook); /*4*/
	                                  
	/*add to book-libBook multi map*/
	unsigned int isbn = newlibBook->getIsbn();
	m_bookLibBookMMap.insert (pair<unsigned int,LibraryBook*>(isbn,newlibBook));   /*5*/	
	
	return callNum;
}

void Library::IncLibBookCount(const LibraryBook* _book)
{
	unsigned int isbn = _book->getIsbn();
	ItrBookCount itrBookCount = m_bookCountMap.find(isbn);
	if(itrBookCount == m_bookCountMap.end() ){
		BookCount* newBookCount = new BookCount; 
		newBookCount->m_count = 1;
		newBookCount->m_countOut = 0;
		m_bookCountMap[isbn] = newBookCount;	 
	}else{
		itrBookCount->second->m_count++;
	}
}
/*------------------------------------------------------------------------------------*/

bool Library::RemoveLibBook(unsigned int _callNum)
{
	ItrLibBook itrLibBook = SearchLibBookImp(_callNum);	
	
	/*check if exists*/
	if(itrLibBook == m_libBookMap.end() ){
		return false;
	}
	
	LibraryBook* libBook = itrLibBook->second;
	
	/*check if out*/
	if( libBook->getStatus() == OUT){
		return false;
	}
	
	/*bookCountMap-- */
	DecLibBookCount(libBook);    /*4*/
		
	/*remove from libBookMap*/
	m_libBookMap.erase(itrLibBook);  /*3*/
	
	/*remove from book-libBook multi map*/
	ItrMMbookLibBook  itrMMbookLibBook =  m_bookLibBookMMap.find(libBook->getIsbn());
	while(itrMMbookLibBook != m_bookLibBookMMap.end()  &&   itrMMbookLibBook->second != libBook){
		++itrMMbookLibBook;
	} 
	if(itrMMbookLibBook == m_bookLibBookMMap.end()){ /*not suppose to happen !!!!*/
		throw _callNum;
	}else{
		m_bookLibBookMMap.erase(itrMMbookLibBook);    /*5*/
	}
	
	
	delete(libBook);

	return true;
}
	
void Library::DecLibBookCount(const LibraryBook* _book)
{
	unsigned int isbn = _book->getIsbn();
	ItrBookCount itrBookCount = m_bookCountMap.find(isbn);
	if(itrBookCount == m_bookCountMap.end() ){  /*not supose to happen!!!!*/
		throw isbn;
	}	
	
	BookCount* bookCount = itrBookCount->second;
	--(bookCount->m_count); 
}	

	
/*------------------------------------------------------------------------------------*/	

void Library::PrintCusts() const
{	
	for(CItrBorrwer itr = m_custMap.begin() ; itr != m_custMap.end() ; itr++){
		itr->second->Print();
	}
}	

void Library::PrintLibBooks() const
{
	for(CItrLibBook itr = m_libBookMap.begin() ; itr != m_libBookMap.end() ; itr++){
		itr->second->Print();
	}	
}
/*------------------------------------------------------------------------------------*/		
	
ItrLibBook Library::SearchLibBookImp(unsigned int _callNum)
{
	ItrLibBook itrLibBook = m_libBookMap.find(_callNum);
	return itrLibBook;
}

LibraryBook* Library::SearchLibBook(unsigned int _callNum)
{
	ItrLibBook itrLibBook = SearchLibBookImp(_callNum);
	if(itrLibBook == m_libBookMap.end() ){
		return NULL;
	}else{
		return itrLibBook->second;
	}
}
	
/*------------------------------------------------------------------------------------*/			
	
ItrBorrwer Library::SearchBorrowerImp(unsigned int _custNum)
{
	ItrBorrwer itrBorrwer = m_custMap.find(_custNum);
	return itrBorrwer;
}

ItrBorrwer Library::SearchBorrowerByIdImp(unsigned int _id)
{
	ItrBorrwer itrBorrwer = m_custMapId.find(_id);
	return itrBorrwer;
}
	
Borrower* Library::SearchBorrower(unsigned int _id)
{
	ItrBorrwer itrBorrwer = SearchBorrowerByIdImp(_id);
	if(itrBorrwer == m_custMapId.end() ){
		return NULL;
	}else{
		return itrBorrwer->second;
	}

}
	
/*------------------------------------------------------------------------------------*/		

bool Library::BorrowBook(unsigned int _custId, unsigned int _isbn)
{
	/*checks for avaliable books*/
	ItrBookCount itrBookCount = m_bookCountMap.find(_isbn);
	if(itrBookCount == m_bookCountMap.end() ){
		return false;
	}

	BookCount* bookCount = itrBookCount->second;
	if(bookCount->m_count - bookCount->m_countOut <= 0){
		return false;
	}

	return true;
}

/*------------------------------------------------------------------------------------*/		


































		
	
