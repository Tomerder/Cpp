#include <iostream>
#include <string.h>

#include "library.h"

using namespace std;

#define SIZE 10

#define MIN_ID 111111111

/*------------------------------------------------------------------------------------*/

void interactiveMain();

void InitPersons(Person* arrOfPersons);	
void InitBooks(Book* arrOfBooks);	

/*------------------------------------------------------------------------------------*/

int main() 
{
	Library lib;
	
	cout << "/*--------------------------------------------------------*/" << endl;
	
	Person per1(784651654,"tomer","haifa",30);
	Person per2(777777777,"dudu","tl",40);
	
	Book bk1(111111111,"book1","autur1",MISTORY,50);
	Book bk2(222222222,"book2","autur2",GENERAL);
	Book bk3(333333333,"book3","autur3",GENERAL);
	Book bk4(444444444,"book4","autur4",MISTORY,77);
	
	lib.AddBorrower(per1);
	lib.AddBorrower(per2);
		
	lib.PrintCusts();
	cout << "/*--------------------------------------------------------*/" << endl;
	
	lib.AddLibBook(bk1);
	lib.AddLibBook(bk1);
	lib.AddLibBook(bk1);
	lib.AddLibBook(bk2);
	lib.AddLibBook(bk2);
	lib.AddLibBook(bk3);		
	
	
	lib.PrintLibBooks();	
	cout << "/*--------------------------------------------------------*/" << endl;
	
	lib.RemoveLibBook(4);
	lib.RemoveLibBook(2);
	lib.AddLibBook(bk4);	
	lib.PrintLibBooks();
	cout << "/*--------------------------------------------------------*/" << endl;
	
	
	
	interactiveMain();	

	return 0;
}

/*------------------------------------------------------------------------------------*/

void InitPersons(Person** arrOfPersons)
{
	string Names[SIZE] = {"dudu" , "tomer" , "yosi" , "sara" ,"david" , "neta", "reut" , "natan" , "kuku" , "dana"};
	for(int i=0; i<SIZE; i++){
		arrOfPersons[i] = new Person(i+(777*i),Names[i],"city " + i ,i*10);
	}
}	

void InitBooks(Book** arrOfBooks)
{
	string Names[SIZE] = {"dudu" , "tomer" , "yosi" , "sara" ,"david" , "neta", "reut" , "natan" , "kuku" , "dana"};
	for(int i=0; i<SIZE; i++){
		arrOfBooks[i] = new Book(i+(555*i),"book " + i , Names[i] , GENERAL ,i*10);
	}
}	
/*------------------------------------------------------------------------------------*/
void AddBookMain(Library* _lib, Book** _arrOfBooks)
{
	int bookNum , callNum;
	cout << "you have " << SIZE << " kind of books for test. enter book number to add to library :";
	cin >> bookNum;

	if( bookNum < SIZE ){
		callNum = _lib->AddLibBook(*_arrOfBooks[bookNum - 1]);
	}

	if(callNum > 0){
		cout << "call number of added book is: " << callNum << endl;
		_lib->PrintLibBooks();
	}else{
		cout << "error!!!" << endl;
	}
}

void AddCustMain(Library* _lib, Person** _arrOfPersons)
{
	int personNum , custNum;
	cout << "you have " << SIZE << " persons for test. enter persons number to add as customer :";
	cin >> personNum;

	if( personNum < SIZE ){
		custNum = _lib->AddBorrower(*_arrOfPersons[personNum - 1]);
	}

	if(custNum > 0){
		cout << "cust number of added customer is: " << custNum << endl;
		_lib->PrintCusts();
	}else{
		cout << "error!!!" << endl;
	}
}
/*------------------------------------------------------------------------------------*/

void RemoveBookMain(Library* _lib)
{
	int callNum;
	cout << "Enter call num to remove :";
	cin >> callNum;

	if (_lib->RemoveLibBook(callNum)){
		cout << "book removed" << endl;
		_lib->PrintLibBooks();
	}else{
		cout << "error!!!" << endl;
	}
}

void RemoveCustMain(Library* _lib)
{
	int custNum;
	cout << "Enter cust num to remove :";
	cin >> custNum;

	if (_lib->RemoveBorrower(custNum)){
		cout << "customer removed" << endl;
		_lib->PrintCusts();
	}else{
		cout << "error!!!" << endl;
	}
}
/*------------------------------------------------------------------------------------*/
void SearchBookMain(Library* _lib)
{


}

void SearchCustMain(Library* _lib)
{


}

/*------------------------------------------------------------------------------------*/
void interactiveMain()
{
	Library* lib = new Library;
	Person* arrOfPersons[SIZE];
	Book* arrOfBooks[SIZE];	

	InitPersons(arrOfPersons);	
	InitBooks(arrOfBooks);	


	char ch;
	
	int cont = 1;
	
	while(cont) {
		cout << endl;
		cout << "1 - add a book" 	<< endl;
		cout << "2 - add customer" 	<< endl;
		cout << "3 - remove book" 	<< endl;
		cout << "4 - remove customer" 	<< endl;
		cout << "5 - search book" 	<< endl;
		cout << "6 - search customer" 	<< endl;
		cout << "7 - borrow book" 	<< endl;
		cout << "8 - return book" 	<< endl;
		cout << "9 - print books" 	<< endl;
		cout << "0 - print customers" 	<< endl;
		
		cout << "Please, choose option: ";
	
		cin >> ch;
		
		switch(ch) {
			case '1' : AddBookMain(lib, arrOfBooks) ; break;		
			case '2' : AddCustMain(lib, arrOfPersons) ; break;	
			case '3' : RemoveBookMain(lib) ; break;			
			case '4' : RemoveCustMain(lib) ; break;
			case '5' : SearchBookMain(lib) ; break;			
			case '6' : SearchCustMain(lib) ; break;
				
			case '9' : lib->PrintLibBooks(); break;			
			case '0' : lib->PrintCusts(); break;
	
			default: cont = 0;
		}
	}

	delete lib;

	cout << "/-----------------------------------------------------/" << endl;

}

/*--------------------------------------------------------------------------*/

