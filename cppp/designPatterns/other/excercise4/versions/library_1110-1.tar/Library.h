/***************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-11-10    
    Last modified date:		2013-11-10
    Description: 	Library Management System - design
****************************************************************************/

#ifndef __LIBRARY_H__
#define __LIBRARY_H__

#include <vector>

#include "observer.h"
#include "subject.h"



//=======================================================================//
//	BOOK - an observer's subject, and a composite: all copies of the same
//			book are under the same "book"
//=======================================================================//
class Book_t : public Subject_t
{
public:
	
	// CTOR, DTOR
	virtual ~Book_t();
	// CTOR non expliciton purpose - can accept e.g. char*
	virtual Book_t(std::string _title, std::string _author);
	virtual Book_t(const Book_t& _other);
	
	virtual void Notify(void* _params, char* _txt=0);	// NOTIFY observers, call children's functions recuresively
	
	// inherited
//  virtual void Attach(Observer_t*);	// func for observers to call
//  virtual void Detach(Observer_t*);
//  std::vector<Observer_t*> m_observers; // list of observers (who called Attach)
	
	
private:
	std::string m_title;
	std::string m_author;
	// category m_category;
	size_t m_id;
	
	static size_t BOOK_ID;
	
	// no assignment - one book can't turn into another
	Book_t& operator =(const Book_t& _other);
};
//=======================================================================//


class BookCopy_t : public Book_t
{

};

//=======================================================================//
//			BORROWER - an observer (of multiple subjects)
//=======================================================================//
class Borrower_t : public Observer_t
{
public:
	
	// CTOR, DTOR
	virtual ~Borrower_t();
	// CTOR non expliciton purpose - can accept e.g. char*
	virtual Borrower_t(std::string _name, std::string _address, std::string _phone);
	
	// copy/assignment - can copy address & phone, not name (or ID)
	Borrower_t(const Borrower_t& _other, std::string _name);
	Borrower_t& operator =(const Borrower_t& _other, std::string _name);
	
	// UPDATE function - get nofifications from subject
	virtual void Update(Subject_t* _sbj, char* _txt = 0); 

	
private:
	std::string m_name;
	std::string m_address;
	std::string m_phone;
	size_t m_id;
	
	// inherited
//	vector<Subject_t*> m_sbj;	// vector of subjects = books

//	std::vector<Book_t*> m_books;
	
	static size_t BORROWER_ID;
	
};
//=======================================================================//




//=======================================================================//
//					BOOK ADMINISTRATION - a Singleton
//=======================================================================//
class BookAdmin_t
{
public:
	
	// CTOR, DTOR
	virtual ~Borrower_t();
	
	
	
};
//=======================================================================//


//=======================================================================//
//					BORROWER ADMINISTRATION - a Singleton
//=======================================================================//
class BorAdmin_t
{
public:
	
	// CTOR, DTOR
	virtual ~BorAdmin_t();
	
	
	
};
//=======================================================================//


#endif  /* __LIBRARY_H__ */


