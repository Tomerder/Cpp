/***************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-11-07    
    Last modified date:		2013-11-07
    Description: 	convert decimal number to roman numerals
****************************************************************************/

#ifndef __INTERPRETER_H__
#define __INTERPRETER_H__



class Dec2Roman_t
{
public:
	// CTOR, DTOR
	virtual ~Dec2Roman_t();
	explicit Dec2Roman_t();
	
	// empty CTOR to prevent infinite loop
	explicit Dec2Roman_t(int) {}
	
	std::string& interpret(int _num);
	
	virtual void interpretImp(int _num, std::string& _result) {};
	
	void Clean()	{ result.clear(); }
	
protected:
	
private:
	std::string result;
	
	Dec2Roman_t* ones2hundreds;
	Dec2Roman_t* thousands;
	
//	Dec2Roman_t* ones;
//	Dec2Roman_t* tens;
//	Dec2Roman_t* hundreds;
	
	// no copy
	Dec2Roman_t(const Dec2Roman_t& _d2r);
	Dec2Roman_t& operator =(const Dec2Roman_t& _d2r);
};
// ===================================================================== //


class Thousands_t : public Dec2Roman_t
{
public:
	Thousands_t() : Dec2Roman_t(1) {};
	virtual ~Thousands_t() {};
	
	virtual void interpretImp(int _num, std::string& _result);
	
private:
	static const char* oneThousand;
};
// ===================================================================== //


class Ones2Hundreds_t : public Dec2Roman_t
{
public:
	Ones2Hundreds_t() : Dec2Roman_t(1) {};
	virtual ~Ones2Hundreds_t() {};
	
	virtual void interpretImp(int _num, std::string& _result);
	
private:
	static const char** Lookups[3];
	
	static const char* OnesLookup[10];
	static const char* TensLookup[10];
	static const char* HundredsLookup[10];
};
// ===================================================================== //


//class Ones_t : public Ones2Hundreds_t
//{
//public:
//	Ones_t()
//	
//	
//private:
//	
//	static char* OnesLookup[10];
//};
//// --------------------------------------------------------------------- //
//class Tens_t : public Ones2Hundreds_t
//{
//public:
//	
//private:
//	
//	static char* TensLookup[10];
//};
//// --------------------------------------------------------------------- //
//class Hundreds_t : public Ones2Hundreds_t
//{
//public:
//	
//private:
//	
//	static char* HundredsLookup[10];
//};
// ===================================================================== //



#endif  /* __INTERPRETER_H__ */
