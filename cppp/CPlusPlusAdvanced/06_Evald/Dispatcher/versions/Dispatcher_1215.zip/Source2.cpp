
// usage example for dispatcher

class Thermometer
{
public:

	void  ChangeTemp(int _change)
	{
		//notify observers for any temperature change
		if (_change) { m_disp.Dispatch(); }
	}

private:
	m_temp;
	Dispatcher<Thermometer, int> m_disp;
};


class Dog
{
public:
	void Tongue();
}

// implementation of Notify for Dog
template <class T, class D, class O>
void ObserverCB::Notify()
{
	m_observer->Tongue();
}


typedef ObserverCB<int, Thremometer, Dog>		DogTCB;


int main()
{
	Dog d;
	Thermometer t;

	DogTCB(&t, &d); // register dog as observer for thermometer

}



/*
flow:	DogTCB CTOR - 
*/