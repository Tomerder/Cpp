/***************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-11-07    
    Last modified date:		2013-11-07
    Description: 	test for Story.
****************************************************************************/

#include <iostream>
#include "Story.h"
using namespace std;


enum Choices
{
	EXIT,
	
	MK_SEN,
	PRT_SEN,
	
	BBB,
	CCC,
	BBB,
	CCC,
	
	MENU = 100
};


// print choices
void PrintChoices(void)
{
	cout << "Create a sentence: " << MK_SEN << endl;
	cout << "Print existing sentences: " << PRT_SEN << endl;
//	cout << ": " << CCC << endl;
//	cout << ": " << AAA << endl;
//	cout << ": " << BBB << endl;
//	cout << ": " << CCC << endl;

	cout << "Print menu: " << MENU << endl;
	cout << "Exit: " << EXIT << endl;
}
/*######################################################################*/




int main()
{
	const int NUMWORDS = 10;
	const int NUM = 100;
	int choice;
	int i;
	
	Word_t* myWords[NUMWORDS];
	Sentence_t* mySens[NUM];
	Chapter_t* myChaps[NUM];
	SStory_t* mySStory = 0;
	Novel_t myNovel = 0;
	
	int nSens = 0, nChaps = 0;
	
	string abc[NUMWORDS] = {"aa", "bb", "cc", "dd", "ee", "ff", "gg", "hh", "ii", "jj"};
	
	
	for(i = 0; i < NUMWORDS, ++i)
	{
		myWords[i] = new Word_t(abc[i]);
	}
	
	
	cout << "The available words are:  ";
	for(int i = 0; i < NUMWORDS, ++i)
	{
		cout << i+1 << ". "
		myWords[i]->Print();
	}
	cout << endl;
	
	
	PrintChoices();
	
	cout << endl << "Enter your choice: ";
	cin >> choice;
	
	while(choice)
	{
		
		switch(choice)
		{
		
		case MK_SEN:	// create sentence
			
			i = 0;
			mySens[nSens] = new Sentence_t;
			
			cout << "enter word number (1-10) to insert it, 0 when you are finished. Note: no repeating words." << endl;
			cin >> i;
			
			while (i != 0)
			{
				if(i<0 || i>10) { cout << "invalid number, try again: "; cin >> i; continue; }
				
				mySens[nSens]->Add(myWords[i-1]);
				cout << "enter next word number, or 0 when you are finished: ";
				cin >> i;
			} 
			
			++nSens;
			break;

		case PRT_SEN:
			if(nSens == 0) { cout << "no Sentences" << endl; break; }
			for(i=0; i<nSens; ++i)
			{
				mySens[i].Print();
			}
			
			break;
		
//		case XX:
//			
//			
//			break;
		
//		case XX:
//			
//			
//			break;
		
//		case XX:
//			
//			
//			break;
		
		case MENU:
		
			PrintChoices();
			cout << endl;
			break;
			
		case EXIT:
		default:
		
			goto DELETE_AND_EXIT;
			
		} // end switch
		
		cout << "Enter next choice (" << MENU << " for menu, " << EXIT << " to exit): ";
		cin >> choice;
	} // end choice
	
	
	
DELETE_AND_EXIT:

	
	if(myNovel) { delete myNovel; }
	if(mySStory) { delete mySStory; }
		
	for(int i = 0; i < nChaps, ++i)
	{
		if(myChaps[i]) { delete myChaps[i]; }
	}
	for(int i = 0; i < nSens, ++i)
	{
		if(mySens[i]) { delete mySens[i]; }
	}
	for(int i = 0; i < NUM, ++i)
	{
		if(myWords[i]) { delete myWords[i]; }
	}
	
	return 0;
}


/*######################################################################*/


