/***************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-11-03    
    Last modified date:		2013-11-03
    Description: 	bank account - bridge to implementations
****************************************************************************/

#ifndef __ACCOUNT_H__
#define __ACCOUNT_H__

class AccImpl_t;
class Observer_t;
class Subject_t;

// types of accounts
enum AccType
{
	PERSONAL,
	FAMILY,
	STOCK
};


class Account_t : public Observer_t
{
public:
	 ~Account_t();
	 Account_t(int _accType, int _money, int _period, Bank_t* _bnk);
	
	void AddMoney(int _money);
	int TakeMoney(int _money);
	
	int GetBalance() const;
	int GetPeriod() const;
	
	virtual void Update(Bank_t* _bnk);
	
protected:
	AccImpl_t*  m_account;
	
	//Subject_t* m_sbj;	// ptr to subject - inherited
};

#endif /* __ACCOUNT_H__ */
