/***************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-11-03    
    Last modified date:		2013-11-03
    Description: 	personal account
****************************************************************************/

#include "bank.h"
#include "accImpl.h"

// CTOR
AccPersonalImpl_t:: AccPersonalImpl_t(int _money, int _period, Bank_t* _bnk) :
	AccImpl_t(_money, _period, _bnk)
{}



// get updates from bank (virtual)
void AccPersonalImpl_t:: Update(Subject_t* _bnk, char* _txt) : AccImpl_t:: Update(_bnk)
{
	//
	cout << _txt << endl;
}
//-----------------------------------------------

