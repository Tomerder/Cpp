/***************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-11-03    
    Last modified date:		2013-11-03
    Description: 	Bank - a singleton, & subject to observers
****************************************************************************/

#ifndef __BANK_H__
#define __BANK_H__


class Subject_t;


class Bank_t : public Subject_t
{
public:
	static Bank_t& GetBank();
	
	void Invest();
	void Bonus();
	void CallMeeting();
	
	// inherited
	
//	virtual void Attach(Observer_t*);	// func for observers to call
//	virtual void Detach(Observer_t*);
    
private:
	static Bank_t& m_bnk; 		// "actual" bank
	
	void Notify(int _acType);
	
	Bank_t() { }				// PRIVATE!
	Bank_t(const Bank_t&);		// no copy 
	void operator=(Bank_t&);	// no assignment
	
	// inherited
	
//	virtual void Notify( void(*_func)(void) )	// NOTIFY
//	map<Observer_t*, int> m_observers; // list of observers (who called Attach)
};



#endif  /* __BANK_H__ */
