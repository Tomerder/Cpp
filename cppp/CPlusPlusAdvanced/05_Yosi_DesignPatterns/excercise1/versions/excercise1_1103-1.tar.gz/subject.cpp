/***************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-11-03    
    Last modified date:		2013-11-03
    Description: 	subject to observers - ABC
****************************************************************************/

#include <iostream>
#include <map>
using namespace std;

#include "subject.h"

// ATTACH
void Subject_t::Attach(Observer_t* _ob, int _type)
{ 
	m_observers.insert( pair<Observer_t*, int>(_ob,_type) ); 
} 
//-----------------------------------------------

// DETACH
void Subject_t ::Detach(Observer_t* _ob)
{ 
	m_observers.erase(_ob);
} 
//-----------------------------------------------

// NOTIFY - protected - not called from outside
void Subject_t :: Notify( void(*_func)(void) )
{ 
	for_each( m_observers.begin(), m_observers.end(), _func);
		
//	for (int i = 0; i < m_observers.size(); i++) 
//		(m_observers[i])->Update(this); // call Update func. in observers
}
//-----------------------------------------------

