/***************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-11-03    
    Last modified date:		2013-11-03
    Description: 	Bank - a singleton, & subject to observers
****************************************************************************/

#include <iostream>

#include "subject.h"
#include "bank.h"


void BonusFam500(map::iterator _itr);




// CTOR
Bank_t:: Bank_t()
{
}


// get ref. to bank
Bank_t& Bank_t:: GetBank()
{
	return m_bnk;
}


void Invest()
{
	//
	
	// Notify
}


void Bonus()
{
	for_each( m_observers.begin(), m_observers.end(), BonusFam500);
	
	Notify(UpdateFamily);
}


void CallMeeting()
{
	//
	
	// Notify
}


// ------------------------------



//struct BonusFam500
//{
//  void operator() ()
//  	{std::cout << ' ' << i;}
//  	
//} BonusFam500;


void BonusFam500(map::iterator _itr)
{
	if( typeid(*_itr) == typeid(AccFamilyImpl_t*) )
	{
		*_itr->AddMoney(500);
	}
}



// for notifications

void UpdatePersonal(map::iterator _itr, char* _txt)
{
	//
}


void UpdateFamily(map::iterator _itr, char* _txt)
{
	if( typeid(*_itr) == typeid(AccFamilyImpl_t*) )
	{
		cout << _txt
	}
}


void UpdateStock(map::iterator _itr, char* _txt)
{
	//
}
