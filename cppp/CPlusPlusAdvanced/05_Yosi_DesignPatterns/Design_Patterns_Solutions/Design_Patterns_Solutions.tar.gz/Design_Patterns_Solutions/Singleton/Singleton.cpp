
#include "Singleton.h"
 
Singleton* Singleton:: sngPtr = 0; // init static data 


