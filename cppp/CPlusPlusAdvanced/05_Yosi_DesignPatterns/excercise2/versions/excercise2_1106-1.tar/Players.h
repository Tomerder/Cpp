/***************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-11-06    
    Last modified date:		2013-11-06
    Description: 	
****************************************************************************/

#ifndef __PLAYERS_H__
#define __PLAYERS_H__

#include "BiduritEnums.h"

//=========================================================================
// 							Abstract Player
//=========================================================================
class PlayerDevice_t
{
public:
	PlayerDevice_t() { m_status = PAUSED; }
	
	virtual void Play () = 0 ;
	virtual void Pause () = 0 ;
	virtual void Foreward () = 0 ;
	virtual void Rewind () = 0 ;
	
	PlayerStatus GetStatus() const { return m_status; }
	
protected:
	PlayerStatus m_status;
	PlayerType	 m_type;
};
//=========================================================================



//-------------------------------------------------------------------------
// 					CD Player - template in manufactorer?
//-------------------------------------------------------------------------
class CDPlayer_t : public PlayerDevice_t
{
public:
	CDPlayer_t() m_type(CD) {}
	
	virtual void Play();
	virtual void Pause();
	virtual void Foreward();
	virtual void Rewind();
	
	//inherited:
//	PlayerStatus 		m_status;
//	const PlayerType	m_type;
};

//-------------------------------------------------------------------------
// 					DVD Player - template in manufactorer?
//-------------------------------------------------------------------------


class DVDPlayer_t : public PlayerDevice_t
{
public:
	DVDPlayer_t() m_type(DVD) {}
	
	virtual void Play();
	virtual void Pause();
	virtual void Foreward();
	virtual void Rewind();
	
		//inherited:
//	PlayerStatus 		m_status;
//	const PlayerType	m_type;
};

//-------------------------------------------------------------------------
// 					VCR Player - template in manufactorer?
//-------------------------------------------------------------------------


class VCRPlayer_t : public PlayerDevice_t
{
public:
	VCRPlayer_t() m_type(VCR) {}
	
	virtual void Play();
	virtual void Pause();
	virtual void Foreward();
	virtual void Rewind();
	
		//inherited:
//	PlayerStatus 		m_status;
//	const PlayerType	m_type;
};


#endif  /* __PLAYERS_H__ */
