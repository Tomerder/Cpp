/***************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-11-06    
    Last modified date:		2013-11-06
    Description: 	
****************************************************************************/

#include <vector>
#include <algorithm>

#include "PlayerFactory.h"
#include "Bidurit.h"



// CTOR
Bidurit_t::Bidurit_t()
{
	PlayerDevice_t* cdPlayer  = new CDPlayer_t;
	PlayerDevice_t* dvdPlayer = new DVDPlayer_t;
	PlayerDevice_t* vcrPlayer = new VCRPlayer_t;
	
	m_players.push_back(cdPlayer);
	m_players.push_back(dvdPlayer);
	m_players.push_back(vcrPlayer);
}
//=========================================================================

// DTOR
Bidurit_t::~Bidurit_t()
{
	for_each(m_players.begin(), m_players.end(), FreeAll);
	m_players.clear();
}
//=========================================================================
// functor for DTOR
void Bidurit_t::FreeAll(PlayerDevice_t& _p)
{
	delete _p;
}
//=========================================================================

// get player of given type 
PlayerDevice_t* Bidurit_t::GetPlayer(PlayerType _type)
{
	return ( *find(m_players.begin(), m_players.end(), _type) );
}
//=========================================================================


// Pause All
void Bidurit_t::PauseAllPlayers()
{
	for_each(m_players.begin(), m_players.end(), PauseAll);
}
//=========================================================================



void PlayerPlay		(PlayerDevice_t* _p)
{
	PauseAllPlayers();
	_p->Play();
}
//=========================================================================

void PlayerPause	(PlayerDevice_t* _p)
{
	_p->Pause();
}
//=========================================================================

void PlayerForeward	(PlayerDevice_t* _p)
{
	_p->Rewind();
}
//=========================================================================

void PlayerRewind	(PlayerDevice_t* _p)
{
	_p->Foreward();
}
//=========================================================================


