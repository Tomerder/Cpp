/***************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-00-00    
    Last modified date:		2013-00-00
    Description: 	
****************************************************************************/

#include <iostream>
//#include <cstring>

using namespace std;

#include "BiduritEnums.h"
#include "Players.h"
#include "PlayerFactory.h"
//#include "Bidurit.h"


enum Choices
{
	EXIT,
	
	AAA,
	BBB,
	CCC,
	
	MENU = 100
};


void PrintChoices(void);

/*######################################################################*/



int main()
{
//	Bidurit_t B;
//	PlayerDevice_t* dvd = B.GetPlayer(DVD);
	
	
	PlayerFactory_t* CDF =  new CDFactory_t;
//	PlayerFactory_t* DVDF = new DVDFactory_t;
//	PlayerFactory_t* VCRF = new VCRFactory_t;
	
	
	PlayerDevice_t* cd = CDF->MakePlayer();
	
	cd->Play();
	cd->Pause();
	
	
	
	
	
//	PrintChoices();
//	
//	cout << endl << "Enter your choice: ";
//	cin >> choice;
//	
//	while(choice)
//	{
//		
//		switch(choice)
//		{
//		
////		case XX:
////			
////			
////			break;

////		case XX:
////			
////			
////			break;
//		
////		case XX:
////			
////			
////			break;
//		
//		case MENU:
//		
//			PrintChoices();
//			cout << endl;
//			break;
//			
//		case EXIT:
//		default:
//		
//			return 0;
//			
//		} // end switch
//		
//		cout << "Enter next choice (" << MENU << " for menu, " << EXIT << " to exit): ";
//		cin >> choice;
//	} // end choice
	
	return 0;
}


/*######################################################################*/

// print choices
void PrintChoices(void)
{
	//	cout << ": " << AAA << endl;
	//	cout << ": " << BBB << endl;
	//	cout << ": " << CCC << endl;

	cout << "Print menu: " << MENU << endl;
	cout << "Exit: " << EXIT << endl;
}
/*######################################################################*/

