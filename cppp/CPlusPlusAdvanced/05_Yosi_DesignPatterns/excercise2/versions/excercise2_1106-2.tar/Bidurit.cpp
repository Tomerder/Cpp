/***************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-11-06    
    Last modified date:		2013-11-06
    Description: 	
****************************************************************************/

#include <vector>
#include <algorithm>

#include "PlayerFactory.h"
#include "Players.h"
#include "Bidurit.h"

using namespace std;

// functor for DTOR
void FreeAll(PlayerDevice_t* _p);

// functor for PauseAllPlayers
void PauseAllFunc(PlayerDevice_t* _p);



// CTOR
Bidurit_t::Bidurit_t()
{
	PlayerDevice_t* cdPlayer  = new CDPlayer_t;
	PlayerDevice_t* dvdPlayer = new DVDPlayer_t;
	PlayerDevice_t* vcrPlayer = new VCRPlayer_t;
	
	m_players.push_back(cdPlayer);
	m_players.push_back(dvdPlayer);
	m_players.push_back(vcrPlayer);
}
//=========================================================================

// DTOR
Bidurit_t::~Bidurit_t()
{
	for_each(m_players.begin(), m_players.end(), FreeAll);
	m_players.clear();
}
//=========================================================================
// functor for DTOR
void FreeAll(PlayerDevice_t* _p)
{
	delete _p;
}
//=========================================================================


// functor for PauseAllPlayers
void PauseAllFunc(PlayerDevice_t* _p)
{
	if(_p->GetStatus() == PLAYING) { _p->Pause(); }
}

// Pause All
void Bidurit_t::PauseAllPlayers()
{	
	for_each(m_players.begin(), m_players.end(), PauseAllFunc);
}
//=========================================================================

// functor for GetPlayer
class FindType
{
public:
	explicit FindType(PlayerType _type) : m_type(_type) {}
	int operator ()(PlayerDevice_t* _p)
	{
		return (_p->GetType() == m_type);
	}
	
private:
	PlayerType m_type;
};

// get player of given type 
PlayerDevice_t* Bidurit_t::GetPlayer(PlayerType _type)
{
	vector<PlayerDevice_t*>::iterator _itr;
	_itr = find_if(m_players.begin(), m_players.end(), FindType(_type));
	
	return *_itr;
}
//=========================================================================



void Bidurit_t::PlayerPlay		(PlayerDevice_t* _p)
{
	PauseAllPlayers();
	_p->Play();
}
//=========================================================================

void Bidurit_t::PlayerPause	(PlayerDevice_t* _p)
{
	_p->Pause();
}
//=========================================================================

void Bidurit_t::PlayerForeward	(PlayerDevice_t* _p)
{
	_p->Rewind();
}
//=========================================================================

void Bidurit_t::PlayerRewind	(PlayerDevice_t* _p)
{
	_p->Foreward();
}
//=========================================================================



