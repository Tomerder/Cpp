/**************************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-10-23    
    Last modified date:		2013-10-23
    Description: "translating" c++ code to c
***************************************************************************************/

#include <stdlib.h>
#include <stdio.h>

#include "ccode.h"


#define CHECK_MALLOC(X)		if(!(X)) { fprintf(stderr, "malloc failed, line %d\n", __LINE__); return -1; }


/*######################################################################*/
/*						GLOBAL VARIABLES								*/
/*######################################################################*/

/* virtual tables */
extern Func vtblShape[];
extern Func vtblCircle[];
extern Func vtblSquare[];

extern int NShapes;


/*######################################################################*/
/*								FUNCTIONS								*/
/*######################################################################*/


void f1(Shape *_shape)
{
	((void(*)(Shape*))( _shape->m_vtbl[1] ))(_shape);	/* draw */
}
/************************************************************************/

void f2(void)
{
	PrintNShapes();
}
/************************************************************************/

void f3(Circle _cParam)
{
	Circle c;
	Circle_CCTOR(&c, &_cParam);
	
	((void(*)(Circle*))( c.m_shape.m_vtbl[1] ))(&c);	/* draw */
	
	(*((CircleDtor*)c.m_shape.m_vtbl))(&c);	/* DTOR */
}
/************************************************************************/



/*######################################################################*/
/*									MAIN								*/
/*######################################################################*/
int main()
{
	Shape *array[3], arr2[3];
	Circle c, c2, arr3[4], cTemp;
	Square *arr4, sqTemp;
	int i;
	
	Init();

	/* create c & call f3 */
	Circle_CTOR(&c);
	f3(c);
	
	/* array: allocate */
	array[0] = (Shape*)malloc(sizeof(Circle));
	CHECK_MALLOC(array[0]);
	Circle_CTOR( (Circle*)array[0] );
	
	array[1] = (Shape*)malloc(sizeof(Square));
	CHECK_MALLOC(array[1]);
	Square_CTOR( (Square*)array[1] );
	
	array[2] = (Shape*)malloc(sizeof(Circle));
	CHECK_MALLOC(array[2]);
	Circle_CTOR( (Circle*)array[2] );
	
	/* array: draw */
	( (void(*)(Circle*)) ( ((Circle*)array[0])->m_shape.m_vtbl[1] )) (array[0]);
	( (void(*)(Square*)) ( ((Square*)array[1])->m_shape.m_vtbl[1] )) (array[1]);
	( (void(*)(Circle*)) ( ((Circle*)array[2])->m_shape.m_vtbl[1] )) (array[2]);
	
	/* array: delete */
	( *( (CircleDtor*) ((Circle*)array[0])->m_shape.m_vtbl) ) (array[0]);
	free(array[0]);
	
	( *( (SquareDtor*) ((Square*)array[1])->m_shape.m_vtbl) ) (array[1]);
	free(array[1]);
	
	( *( (CircleDtor*) ((Circle*)array[2])->m_shape.m_vtbl) ) (array[2]);
	free(array[2]);
	
	
	/* arr2: create */
	Circle_CTOR( &cTemp );									/* create temporary */
	Shape_CCTOR(&arr2[0], &cTemp.m_shape );					/* copy to arr2[0] (only shape part) */
	( *( (CircleDtor*)cTemp.m_shape.m_vtbl ) ) (&cTemp);	/* destroy temporary */
	arr2[0].m_vtbl = vtblShape;								/* return vtbl pointer to shape vtbl */
		
	Square_CTOR( &sqTemp );									/* create temporary */
	Shape_CCTOR(&arr2[1], &sqTemp.m_shape );				/* copy to arr2[1] (only shape part) */
	( *( (SquareDtor*)sqTemp.m_shape.m_vtbl ) ) (&sqTemp);	/* destroy temporary */
	arr2[1].m_vtbl = vtblShape;								/* return vtbl pointer to shape vtbl */
	
	Shape_CTOR( &arr2[2] );									/* create arr2[2] */
	
	/* arr2: draw */
	for(i=0; i<3; ++i)
	{
		( (void(*)(Shape*)) ( arr2[i].m_vtbl[1] ) ) (&arr2[i]);
	}
	
	
	PrintNShapes();
	
	Circle_CTOR(&c2);
	PrintNShapes();
	
	/* arr3: create */
	for(i=0; i<4; ++i)
	{
		Circle_CTOR(&arr3[i]);
	}
	
	/* arr4: allocate */
	arr4 = (Square*)malloc(4*sizeof(Square));
	CHECK_MALLOC(arr4);
	
	for(i=0; i<4; ++i)
	{
		Square_CTOR(&arr4[i]);
	}
	
	/* arr4: delete */
	for(i=0; i<4; ++i)
	{
		( *( (SquareDtor*)arr4[i].m_shape.m_vtbl ) ) (&arr4[i]);
	}
	free(arr4);
	
	
	/*** DTORS for remaining objects ***/
	
	/* arr3 */
	for(i=3; i>=0; --i)
	{
		( *( (CircleDtor*)arr3[i].m_shape.m_vtbl ) ) (&arr3[i]);
	}
	
	/* c2 */
	( *( (CircleDtor*)c2.m_shape.m_vtbl ) ) (&c2);
	
	/* arr2 */
	for(i=2; i>=0; --i)
	{
		( *( (ShapeDtor*)arr2[i].m_vtbl ) ) (&arr2[i]);
	}
	
	/* c */
	( *( (CircleDtor*)c.m_shape.m_vtbl ) ) (&c);
	
	return 0;
}
/*######################################################################*/


