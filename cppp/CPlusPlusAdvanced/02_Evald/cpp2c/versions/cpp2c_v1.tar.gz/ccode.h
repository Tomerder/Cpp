/**************************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-10-23
    Last modified date:		2013-10-23
    Description: header file for "translating" c++ code to c
***************************************************************************************/

#ifndef __CCODE_H__
#define __CCODE_H__










#endif /* __CCODE_H__ */
