/**************************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-10-23    
    Last modified date:		2013-10-23
    Description: "translating" c++ code to c
***************************************************************************************/

#include <stdio.h>

#include "ccode.h"


int main()
{




	return 0;
}
