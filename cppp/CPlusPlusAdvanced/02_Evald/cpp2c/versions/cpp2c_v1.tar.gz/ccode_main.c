/**************************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-10-23    
    Last modified date:		2013-10-23
    Description: "translating" c++ code to c
***************************************************************************************/

#include <stdio.h>

/*#include "ccode.h"*/


/*######################################################################*/
/*				TYPEDEFS & FOREWARD DECLARATIONS						*/
/*######################################################################*/

typedef void(*Func)();

typedef struct Shape_t
{
	Func*	m_vtbl;
	int 	m_id;
} Shape;


typedef struct Circle_t
{
	Shape 	m_shape;
	int 	m_radius;
} Circle;


typedef struct Square_t
{
	Shape 	m_shape;
} Square;



typedef int(*ShapeDtor)(Shape*);
typedef int(*CircleDtor)(Circle*);
typedef int(*SquareDtor)(Square*);

/************************************************************************/

void 	Shape_CTOR	(Shape* _shape);
void 	Shape_CCTOR	(Shape* _shape, const Shape* const _other);
int 	Shape_DTOR	(Shape* _shape);
void	Shape_Draw	(Shape* _shape);

void 	Circle_CTOR		(Circle* _circle);
void 	Circle_CCTOR	(Circle* _circle, const Circle* const _other);
int 	Circle_DTOR		(Circle* _circle);
void	Circle_Draw		(Circle* _circle);
void	Circle_Radius	(Circle* _circle);

void 	Square_CTOR		(Square* _square);
void 	Square_CCTOR	(Square* _square, const Square* const _other);
int 	Square_DTOR		(Square* _square);
void	Square_Draw		(Square* _square);

void	PrintNShapes(void);

/************************************************************************/
/*						GLOBAL VARIABLES								*/
/************************************************************************/

/* virtual tables */
Func vtblShape[]  = { (int(*)(Shape*))Shape_DTOR,	(void(*)(Shape*))Shape_Draw };
Func vtblCircle[] = { (int(*)(Circle*))Circle_DTOR,	(void(*)(void))Circle_Draw };
Func vtblSquare[] = { (int(*)(Square*))Square_DTOR,	(void(*)(void))Square_Draw };

int NShapes;	/* initialized to 0 at start of main */


/*######################################################################*/
/*								FUNCTIONS								*/
/*######################################################################*/

void PrintNShapes(void)
{
	printf("NShapes: %d\n", NShapes);
}


/************************************************************************/
/*								SHAPE									*/
/************************************************************************/

void 	Shape_CTOR	(Shape* _shape)
{
	_shape->m_vtbl = vtblShape;
	_shape->m_id = ++NShapes;
	printf("Shape::Ctor()\n");
}
/************************************************************************/

void 	Shape_CCTOR	(Shape* _shape, const Shape* const _other)
{
	_shape->m_vtbl = vtblShape;
	_shape->m_id = ++NShapes;
	printf("Shape::CCtor()\n");
}
/************************************************************************/

int 	Shape_DTOR	(Shape* _shape)
{
	--NShapes;
	printf("Shape::Dtor()\n");
	return sizeof(Shape);
}
/************************************************************************/

void	Shape_Draw	(Shape* _shape)
{
	printf("Shape::Draw() : %d\n", _shape->m_id);
}
/************************************************************************/


/************************************************************************/
/*								CIRCLE									*/
/************************************************************************/

void 	Circle_CTOR		(Circle* _circle)
{
	Shape_CTOR(&_circle->m_shape);
	_circle->m_shape.m_vtbl = vtblCircle;
	_circle->m_radius = 2;
	printf("Circle::Ctor()\n");
}
/************************************************************************/

void 	Circle_CCTOR	(Circle* _circle, const Circle* const _other)
{
	Shape_CCTOR(&_circle->m_shape, &_other->m_shape);
	_circle->m_radius = _other->m_radius;
	printf("Circle::CCtor()\n");
}
/************************************************************************/

int 	Circle_DTOR		(Circle* _circle)
{
	printf("Circle::Dtor()\n");
	_circle->m_shape.m_vtbl = vtblShape;
	
	return (*((ShapeDtor*)_circle->m_shape.m_vtbl))(&_circle->m_shape);
}
/************************************************************************/

void	Circle_Draw		(Circle* _circle)
{
	printf("Circle::Draw()\n");
}
/************************************************************************/

void	Circle_Radius	(Circle* _circle)
{
	printf("Circle::Radius()\n");
}
/************************************************************************/


/************************************************************************/
/*								CIRCLE									*/
/************************************************************************/

void 	Square_CTOR		(Square* _square)
{
	Shape_CTOR(&_square->m_shape);
	_square->m_shape.m_vtbl = vtblSquare;
	printf("Square::Ctor()\n");
}
/************************************************************************/

void 	Square_CCTOR	(Square* _square, const Square* const _other)
{
	Shape_CCTOR(&_square->m_shape, &_other->m_shape);
	printf("Square::CCtor()\n");
}
/************************************************************************/

int 	Square_DTOR		(Square* _square)
{
	printf("Square::Dtor()\n");
	_square->m_shape.m_vtbl = vtblShape;
	
	return (*((ShapeDtor*)_square->m_shape.m_vtbl))(&_square->m_shape);
}
/************************************************************************/

void	Square_Draw		(Square* _square)
{
	printf("Square::Draw()\n");
}
/************************************************************************/


/*######################################################################*/
/*									MAIN								*/
/*######################################################################*/
int main()
{
	Shape s1, s2;
	Circle c1, c2;
	Square sq1, sq2;
	
	NShapes = 0;
	
	Shape_CTOR(&s1);
	Shape_CCTOR(&s2, &s1);
	
	((void(*)(Shape*))( s1.m_vtbl[1] ))(&s1);	/* draw */
	
	PrintNShapes();
	
	
/*	((int(*)(Shape*))s1.m_vtbl[0])(&s1);*/	/* DTOR */
	(*((ShapeDtor*)s1.m_vtbl))(&s1);	/* DTOR */
	
	PrintNShapes();
	
	
	Circle_CTOR(&c1);
	Circle_CCTOR(&c2, &c1);
	
	((void(*)(Circle*))( c2.m_shape.m_vtbl[1] ))(&c2);	/* draw */
	
	
	Square_CTOR(&sq1);
	Square_CCTOR(&sq2, &sq1);
	
	((void(*)(Square*))( sq2.m_shape.m_vtbl[1] ))(&sq2);	/* draw */
	
	PrintNShapes();
	
	
	(*((CircleDtor*)c1.m_shape.m_vtbl))(&c1);	/* DTOR */
	(*((SquareDtor*)sq1.m_shape.m_vtbl))(&sq1);	/* DTOR */
	
	PrintNShapes();
	
	return 0;
}
/*######################################################################*/




