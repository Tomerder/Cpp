/***************************************************************************
	Author: Stav Ofer
	Creation date:  		2013-11-04    
	Last modified date:		2013-11-04
	Description: 	Bitset class implementation
/***************************************************************************/

#include <cassert>
#include <vector>
#include <algorithm>

#include "bitset.h"

using namespace std;
using namespace bitset_namespace;


// !!! to put in class BitsetService

//void RightShiftImp(vector::iterator _itr, size_t _jump, size_t _shift);
//void LeftShiftImp(vector::reverse_iterator _itr, size_t _jump, size_t _shift);


//######################################################################//


// and/or
void BitsetService:: AndOr(vector<size_t>& _this, const vector<size_t>& _other, LogicAndOr _andOr)
{
	assert( _this.size() == _other.size() );	// ???
	
	// get ptr to relevant function
	void(*)(size_t&, size_t&) func = (_andOr == AND) ? AndImp : OrImp;
	
	// act on the range [_this.begin, _this.end) and the range starting at _other.begin,
	// storing the results in the range starting at _this.begin, applying func
	transform( _this.begin(), _this.end(), _other.begin(), _this.begin(), func );
}

//----------------------- functions for AndOr ----------------------------//

size_t BitsetService:: AndImp(size_t _numThis, size_t _numOther)
{
	 return (_numThis & _numOther);
}
//---------------------------------------------------------------------
size_t BitsetService:: OrImp(size_t _numThis, size_t _numOther)
{
	return (_numThis | _numOther);
}
//---------------------------------------------------------------------
//######################################################################//


// shift left/right
void BitsetService:: Shift(vector<size_t>& _this, size_t _move, Sides _side)
{
	size_t jump = _move/BITS_IN_WORD;
	size_t shift = _move % BITS_IN_WORD;
	size_t complement = BITS_IN_WORD - _shift;
	
	
	// !!! clean - check big/little endian !!!
	
	
	
	if(_side==RIGHT)
	{
		vector::iterator rightItr = _this.begin();	// iterator for shift right
		for(int i=0; i<_this.size()-jump; ++i, ++rightItr)
		{
			*rightItr = (*(rightItr + jump) >> shift;
			
			size_t temp = (*(rightItr+1)) << complement;
			*rightItr |= temp;
		}
		
	}
	else {
		vector::reverse_iterator leftItr = _this.rbegin(); // reverse itr for shift left
		for(int i=0; i<_this.size()-jump; ++i, ++leftItr)
		{
			*leftItr = (*(leftItr + jump) << shift;
			
			size_t temp = (*(leftItr+1)) >> complement;
			*leftItr |= temp;
		}
	}
}
//######################################################################//







// old - for_each not good b/c acting on *iterator, but here we need to go back and forth
// along the vector with the iterator, so dereferenced is not good enough

//// shift left/right
//void BitsetService:: BitsetService:: Shift(vector<size_t>& _this, size_t _move, Sides _side)
//{
//	size_t jump = _move/BITS_IN_WORD;
//	size_t shift = _move % BITS_IN_WORD;
//	
//	vector::iterator rightItr = _this.begin();	// iterator for shift right
//	vector::reverse_iterator leftItr = _this.rbegin(); // reverse itr for shift left
//	
//	// use for_each with relevant function (left/right)
//	if(_side==RIGHT)
//	{
//		for_each(rightItr, _this.end(), ShiftFunctor(jump, shift, RightShiftImp)); // ??
//	}
//	else {
//		for_each(leftItr, _this.rend(), ShiftFunctor(jump, shift, LeftShiftImp)); // ??
//	}
//	
//	
//	
//	
//}


////--------------------- functors for for_each --------------------------//

//struct ShiftFunctor
//{
//	inline explicit ShiftFunctor(size_t _jump, size_t _shift, /*void(*_func)()*/ );
//	inline void operator()(size_t& _num);
//	
//	size_t m_jump;
//	size_t m_shift;
////	void(*)(/**/) m_func;
//};
////---------------------------------------------------------------------

//inline ShiftFunctor:: ShiftFunctor(size_t _jump, size_t _shift, /*void(*_func)()*/ ) :
//		m_jump(_jump), m_shift(_shift) // , m_func(_func)
//		{}
////---------------------------------------------------------------------
//inline void ShiftFunctor:: operator()(size_t& _num)
//{
//	m_func(_num, m_jump, m_shift);
//}
////---------------------------------------------------------------------



//void BitsetService:: RightShiftImp(size_t& _num, size_t _jump, size_t _shift)
//{
//	size_t complement = BITS_IN_WORD - _shift;
//	
//	
//	
//}
////---------------------------------------------------------------------

//void BitsetService:: LeftShiftImp(size_t& _num _itr, size_t _jump, size_t _shift)
//{
//	
//}
//---------------------------------------------------------------------




