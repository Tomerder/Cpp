/***************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-11-04    
    Last modified date:		2013-11-04
    Description: 	test for bitset class
****************************************************************************/

#include <iostream>
using namespace std;

//#include "bitset.h"
#include "../../Ainclude/bitset.h"

// for now just an example

int main()
{
	Bitset<20> bs1;
	
//	bs1[5] = true;
//	
//	bs1[12] = bs1[5];
//	
//	Bitset bs2(bs1);
//	
//	bs2 <<= 3;
//	
//	bs1 |= bs2;
//	
//	if(bs1[15])
//	{
//		cout << "true" << endl;
//	}
//	
	
	return 0;
}
