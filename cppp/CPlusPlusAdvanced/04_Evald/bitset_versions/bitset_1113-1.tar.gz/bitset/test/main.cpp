/***************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-11-04    
    Last modified date:		2013-11-12
    Description: 	test for bitset class
****************************************************************************/

#include <iostream>

#include "bitset.h"

using namespace std;
using namespace bitset_namespace;

int main()
{
	Bitset<90> bs1;
	
	// empty bitset
	bs1.Print();	cout << endl;
	
	// assignment from bool & proxy
	bs1[8] = true;
	bs1[32] = true;
	bs1[40] = true;
	bs1[72] = bs1[40];
	bs1[73] = bs1[72];
	bs1.Print();	cout << endl;
	
	// shifts
	bs1[73] = false;
	bs1 >>= 3;
	bs1.Print();	cout << endl;
	
	bs1 <<= 30;
	bs1.Print();	cout << endl;
	
	bs1[89] = true;
	bs1.Print();	cout << endl;
	
	bs1 >>= 89;
	bs1.Print();	cout << endl;
	
	bs1 <<= 89;
	bs1.Print();	cout << endl;
	cout << endl << "---------------------------------" << endl << endl;
	
	Bitset<90> bs2 = bs1;
	bs2.Print();	cout << endl;
	
	bs2[10] = bs2[42] = bs2[74] = true;
	bs2.Print();	cout << endl;
	
	bs2 >>= 1;
	bs2.Print();	cout << endl;
	
	bs1 |= bs2;
	bs1.Print();	cout << endl;
	
	bs1 >>= 1;
	bs2 &= bs1;
	bs2.Print();	cout << endl;
	cout << endl << "---------------------------------" << endl << endl;
	
	// shifts - check for garbage
	
	Bitset<10> bs10;
	for(int i=0; i<10; ++i)
	{
		bs10[i] = true;
	}
	
	bs10.Print();
	
	bs10 <<= 3;
	bs10.Print();
	
	bs10 >>= 6;
	bs10.Print();
	
	bs10 <<= 3;
	bs10.Print();
	cout << endl << "---------------------------------" << endl << endl;
	
	
	
	Bitset<155> bs155;
	for(int i=65; i<95; ++i)
	{
		bs155[i] = true;
	}
	
	bs155.Print();	cout << endl;
	
	bs155 >>= 32;
	bs155.Print();	cout << endl;
	
	bs155 <<= 96;
	bs155.Print();	cout << endl;
	
	bs155 >>= 32;
	bs155.Print();	cout << endl;
	
	return 0;
}
