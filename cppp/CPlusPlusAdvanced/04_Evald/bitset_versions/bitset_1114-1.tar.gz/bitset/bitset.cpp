/***************************************************************************
	Author: Stav Ofer
	Creation date:  		2013-11-04    
	Last modified date:		2013-11-14
	Description: 	Bitset class implementation
***************************************************************************/

// TO DO:

// continue test

// Shift: working but ugly, needs some work


#include <cassert>
#include <vector>
#include <algorithm>
#include <iostream>

#include "bitset.h"

using namespace std;
using namespace bitset_service;
using namespace bitset_namespace;

typedef size_t(*ShiftFunc)(size_t _num, size_t _shift);


//----------------------- foreward declarations -------------------------//

// ??? to put in namespace bitset_service ???


element ShiftImp(element _atJump, element _next, size_t _shift, ShiftFunc _func1, ShiftFunc _func2);
element RightShiftImp(element _num, size_t _shift);
element LeftShiftImp(element _num, size_t _shift);
void 	PrintBinary(element _num);
void 	PrintBinLast(element _num, size_t _nBits);

//------------------- functor for transform in Shift --------------------//

struct ShiftFunctor
{
	inline explicit ShiftFunctor(size_t _shift, ShiftFunc _func1, ShiftFunc _func2);
	inline element operator()(element _atJump, element _next);
	
	size_t m_shift;
	
	ShiftFunc m_funcImp1;
	ShiftFunc m_funcImp2;
	
	static element(*m_func)(element, element, size_t, ShiftFunc, ShiftFunc);
};
//---------------------------------------------------------------------
// init. static member
element(*ShiftFunctor::m_func)(element, element, size_t, ShiftFunc, ShiftFunc) = ShiftImp;
//---------------------------------------------------------------------
//CTOR
inline ShiftFunctor::ShiftFunctor(size_t _shift, ShiftFunc _func1, ShiftFunc _func2) :
		m_shift(_shift), m_funcImp1(_func1), m_funcImp2(_func2)
		{}
//---------------------------------------------------------------------
// operator ()
inline element ShiftFunctor::operator()(element _atJump, element _next)
{
	return m_func(_atJump, _next, m_shift, m_funcImp1, m_funcImp2);
}
//---------------------------------------------------------------------



//######################################################################//



// and/or
void bitset_service::AndOr(vector<element>& _this, const vector<element>& _other, ShiftFunc _func)
{
	assert( _this.size() == _other.size() );	// ???
	
	// act on the range [_this.begin, _this.end) and the range starting at _other.begin,
	// storing the results in the range starting at _this.begin, applying _func
	transform( _this.begin(), _this.end(), _other.begin(), _this.begin(), _func );
}
//######################################################################//




// shift left/right
void bitset_service::Shift(vector<element>& _this, size_t _move, void(*_func)(vector<element>&, size_t, size_t, size_t))
{
	size_t shift = _move % BITS_IN_WORD;
	size_t jump =  _move/BITS_IN_WORD;
	size_t range = _this.size()-jump-1;
	
	_func(_this, shift, jump, range);
	
}
//---------------------------------------------------------------------

//implementations of shift right/left
void bitset_service::ShiftRight(vector<element>& _this, size_t _shift, size_t _jump, size_t _range)
{
	vector<element>::iterator rightItr = _this.begin()+_jump;		// iterator for shift right
		
	if( 0 == _range )
	{
		*(_this.begin()) = ShiftImp( *rightItr , 0, _shift, RightShiftImp, LeftShiftImp);
		
		//clear "shifted out" words if _move > BITS_IN_WORD
		while(_jump > 0)
		{
			*(_this.begin()+_jump) = 0;
			--_jump;
		}
		return;
	}
	
	vector<element>::iterator rightLast = rightItr+_range;
	
	// act on the range [_this.begin+_jump, _this."one-before-last") and the range starting at begin+_jump+1
	// storing the results in the range starting at _this.begin, applying ShiftFunctor
	transform( rightItr, rightLast, rightItr+1, _this.begin(),
			ShiftFunctor(_shift, RightShiftImp, LeftShiftImp) );
	
	// last action handled separately to avoid overflow
	*(rightLast) = ShiftImp( *(rightLast+_jump), 0, _shift, RightShiftImp, LeftShiftImp);
	
	//clear "shifted out" words if _move > BITS_IN_WORD
	while(_jump > 0)
	{
		*(rightLast+_jump-1) = 0;
		--_jump;
	}
}
//---------------------------------------------------------------------

void bitset_service::ShiftLeft(vector<element>& _this, size_t _shift, size_t _jump, size_t _range)
{
	vector<element>::reverse_iterator leftItr = _this.rbegin()+_jump; // reverse itr for shift left
		
	if( 0 == _range )
	{
		*(_this.rbegin()) = ShiftImp( *leftItr , 0, _shift, LeftShiftImp, RightShiftImp);
		
		//clear "shifted out" words if _move > BITS_IN_WORD
		while(_jump > 0)
		{
			*(_this.rbegin()+_jump) = 0;
			--_jump;
		}
		return;
	}
	
	vector<element>::reverse_iterator leftLast = leftItr+_range;
	
	transform( leftItr, leftLast, leftItr+1, _this.rbegin(),
			ShiftFunctor(_shift, LeftShiftImp, RightShiftImp) );
	
	// last action hadled separately to avoid overflow
	*(leftLast) = ShiftImp( *(leftLast+_jump), 0, _shift, LeftShiftImp, RightShiftImp);
	
	//clear "shifted out" words if _move > BITS_IN_WORD
	while(_jump > 0)
	{
		*(leftLast+_jump-1) = 0;
		--_jump;
	}
}
//######################################################################//



// single-element shift implementation
element ShiftImp(element _atJump, element _next, size_t _shift, ShiftFunc _func1, ShiftFunc _func2)
{
	return  _func1(_atJump, _shift) | _func2(_next, BITS_IN_WORD - _shift);
}
//---------------------------------------------------------------------

// actual shift left/right
element RightShiftImp(element _num, size_t _shift)
{
	return _num >> _shift;
}
//---------------------------------------------------------------------
element LeftShiftImp(element _num, size_t _shift)
{
	return _num << _shift;
}
//######################################################################//


// print
void bitset_service::PrintImp(vector<element>& _this , size_t _numBits)
{
//	for_each(_this.begin(), _this.end(), PrintBinary);
	
	for_each(_this.begin(), _this.begin()+_this.size()-1, PrintBinary);
	
	_numBits = (_numBits%BITS_IN_WORD) ? _numBits%BITS_IN_WORD : BITS_IN_WORD;
	PrintBinLast( *(_this.begin()+_this.size()-1), _numBits);
}
//---------------------------------------------------------------------

//------------------------ functor for PrintImp -------------------------//
/* print an integer in binary */
void PrintBinary(element _num)
{
	element mask = 1 << (BITS_IN_WORD - 1);
	
	for(size_t i=0 ; mask > 0; mask >>= 1, ++i )
	{
		if( !(i%8) && i) {
			cout << "|";
		}
		cout << ( (_num & mask) != 0 );
	}
	cout << endl;
}
//---------------------------------------------------------------------
// print last element w/o excess bits
void PrintBinLast(element _num, size_t _nBits)
{
	size_t i;
	
	for( i=BITS_IN_WORD; i>_nBits; --i )
	{
		cout << " ";
		if( !((i+1)%8) && i && i!=BITS_IN_WORD-1) {
			cout << " ";
		}
	}
	
	element mask = 1 << (_nBits - 1);
	
	for(i=_nBits-1 ; mask > 0; mask >>= 1, --i )
	{
		if( !( (i+1) %8) && i) {
			cout << "|";
		}
		cout << ( (_num & mask) != 0 );
	}
	cout << endl;
}
//######################################################################//


