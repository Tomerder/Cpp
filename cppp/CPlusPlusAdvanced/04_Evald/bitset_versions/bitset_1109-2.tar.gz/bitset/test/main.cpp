/***************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-11-04    
    Last modified date:		2013-11-09
    Description: 	test for bitset class
****************************************************************************/

#include <iostream>

#include "bitset.h"

using namespace std;
using namespace bitset_namespace;

// for now just an example

int main()
{
	Bitset<96> bs1;
	
	bs1.Print();	cout << endl;
	
	
	bs1[5] = true;
	bs1[12] = true;
	bs1[32] = true;
	bs1.Print();	cout << endl;
	
	
	bs1 >>= 3;
	bs1.Print();	cout << endl;
	
	bs1 <<= 30;
	bs1.Print();	cout << endl;
	
	bs1[95] = true;
	bs1.Print();	cout << endl;
	
	bs1 >>= 95;
	bs1.Print();	cout << endl;
	
	bs1 <<= 95;
	bs1.Print();	cout << endl;
	
	
//	bs1[19] = bs1[5];
//	bs1.Print();
	

//	Bitset<20> bs2 = bs1;
//	
//	bs2 <<= 3;
//	bs2.Print();
	
//	bs1 |= bs2;
//	
//	if(bs1[15])
//	{
//		cout << "true" << endl;
//	}
	
	
	return 0;
}
