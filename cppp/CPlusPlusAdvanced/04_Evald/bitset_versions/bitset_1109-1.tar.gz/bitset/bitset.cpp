/***************************************************************************
	Author: Stav Ofer
	Creation date:  		2013-11-04    
	Last modified date:		2013-11-09
	Description: 	Bitset class implementation
***************************************************************************/

#include <cassert>
#include <vector>
#include <algorithm>

#include "bitset.h"

using namespace std;
using namespace bitset_service;
using namespace bitset_namespace;

typedef size_t(*ShiftFunc)(size_t _num, size_t _shift);


// continue work on shift functions


// ??? to put in namespace bitset_service ???

//element RightShiftImp(element _num, size_t _shift)
//element LeftShiftImp(element _num, size_t _shift)


//######################################################################//


// and/or
void AndOr(vector<element>& _this, const vector<element>& _other, ShiftFunc _func)
{
	assert( _this.size() == _other.size() );	// ???
	
	// act on the range [_this.begin, _this.end) and the range starting at _other.begin,
	// storing the results in the range starting at _this.begin, applying _func
	transform( _this.begin(), _this.end(), _other.begin(), _this.begin(), _func );
}

//######################################################################//


// shift left/right
void Shift(vector<size_t>& _this, size_t _move, Sides _side)
{
	size_t jump = _move/BITS_IN_WORD;
	size_t range = _this.size()-jump;
	size_t shift = _move % BITS_IN_WORD;
	size_t complement = BITS_IN_WORD - shift;
	
	
	// !!! clean - check big/little endian !!!
	
	
	
	if(_side==RIGHT)
	{
		vector<element>::iterator rightItr = _this.begin()+jump;		// iterator for shift right
		vector<element>::iterator rightLast = _this.begin()+range;
		
		// act on the range [_this.begin+jump, _this."one-before-last") and the range starting at begin+jump+1
		// storing the results in the range starting at _this.begin, applying ShiftFunctor
		transform( rightItr, rightLast-1, rightItr+1, _this.begin(),
				ShiftFunctor(shift, _this.size(), RightShiftImp, LeftShiftImp) );
		
		// last action hadled separately to avoid overflow
		*rightLast = ShiftImp(rightLast+jump, 0, RightShiftImp, LeftShiftImp);
		
	}
//	else {
//		vector<element>::reverse_iterator leftItr = _this.rbegin()+jump; // reverse itr for shift left
//		vector<element>::reverse_iterator leftLast = _this.rbegin()+range;
		
//		transform( leftItr, leftLast-1, leftItr+1, _this.rbegin(),
//				ShiftFunctor(shift, _this.size(), LeftShiftImp, RightShiftImp) );
//		
//		// last action hadled separately to avoid overflow
//		*leftLast = ShiftImp(leftLast+jump, 0, LeftShiftImp, RightShiftImp);
//	}
}
//######################################################################//


//------------------- functor for transform in Shift --------------------//

struct ShiftFunctor
{
	inline explicit ShiftFunctor(size_t _shift, ShiftFunc _func1, ShiftFunc _func2);
	inline element operator()(element _atJump, element _next);
	
	size_t m_shift;
	
	ShiftFunc m_funcImp1;
	ShiftFunc m_funcImp2;
	
	static size_t(*m_func)(element, element, size_t, ShiftFunc, ShiftFunc);
};
//---------------------------------------------------------------------
// init. static member
ShiftFunctor::m_func = ShiftImp;
//---------------------------------------------------------------------
//CTOR
inline ShiftFunctor::ShiftFunctor(size_t _shift, ShiftFunc _func1, ShiftFunc _func2) :
		m_shift(_shift), m_funcImp1(_func1), m_funcImp2(_func2)
		{}
//---------------------------------------------------------------------
// operator ()
inline element ShiftFunctor::operator()(element _atJump, element _next)
{
	return m_func(_atJump, _next, m_shift, m_funcImp1, m_funcImp2);
}
//---------------------------------------------------------------------


// single-element implementation
element ShiftImp(element _atJump, element _next, size_t _shift, ShiftFunc _func1, ShiftFunc _func2)
{
	return  _func1(_atJump, _shift) | _func2(_next, BITS_IN_WORD - _shift);
}
//---------------------------------------------------------------------

// actual shift left/right
element RightShiftImp(element _num, size_t _shift)
{
	return _num >> _shift;
}
//---------------------------------------------------------------------
element LeftShiftImp(element _num, size_t _shift)
{
	return _num << _shift;
}
//---------------------------------------------------------------------





// shift left/right
//void Shift(vector<size_t>& _this, size_t _move, Sides _side)
//{
//	size_t jump = _move/BITS_IN_WORD;
//	size_t shift = _move % BITS_IN_WORD;
//	size_t complement = BITS_IN_WORD - _move;
//	
//	
//	// !!! clean - check big/little endian !!!
//	
//	
//	
//	if(_side==RIGHT)
//	{
//		vector<size_t>::iterator rightItr = _this.begin();	// iterator for shift right
//		for(size_t i=0; i<_this.size()-jump; ++i, ++rightItr)
//		{
//			*rightItr = ( *(rightItr + jump) >> shift );
//			
//			size_t temp = (*(rightItr+1) << complement);
//			*rightItr |= temp;
//		}
//		
//	}
//	else {
//		vector<size_t>::reverse_iterator leftItr = _this.rbegin(); // reverse itr for shift left
//		for(size_t i=0; i<_this.size()-jump; ++i, ++leftItr)
//		{
//			*leftItr = (*(leftItr + jump) << shift);
//			
//			size_t temp = (*(leftItr+1) >> complement);
//			*leftItr |= temp;
//		}
//	}
//}
//######################################################################//










// old - for_each not good b/c acting on *iterator, but here we need to go back and forth
// along the vector with the iterator, so dereferenced is not good enough

//// shift left/right
//void BitsetService::BitsetService::Shift(vector<size_t>& _this, size_t _move, Sides _side)
//{
//	size_t jump = _move/BITS_IN_WORD;
//	size_t shift = _move % BITS_IN_WORD;
//	
//	vector<size_t>::iterator rightItr = _this.begin();	// iterator for shift right
//	vector<size_t>::reverse_iterator leftItr = _this.rbegin(); // reverse itr for shift left
//	
//	// use for_each with relevant function (left/right)
//	if(_side==RIGHT)
//	{
//		for_each(rightItr, _this.end(), ShiftFunctor(jump, shift, RightShiftImp)); // ??
//	}
//	else {
//		for_each(leftItr, _this.rend(), ShiftFunctor(jump, shift, LeftShiftImp)); // ??
//	}
//	
//	
//	
//	
//}


////--------------------- functors for for_each --------------------------//

//struct ShiftFunctor
//{
//	inline explicit ShiftFunctor(size_t _jump, size_t _shift, /*void(*_func)()*/ );
//	inline void operator()(size_t& _num);
//	
//	size_t m_jump;
//	size_t m_shift;
////	void(*)(/**/) m_func;
//};
////---------------------------------------------------------------------

//inline ShiftFunctor::ShiftFunctor(size_t _jump, size_t _shift, /*void(*_func)()*/ ) :
//		m_jump(_jump), m_shift(_shift) // , m_func(_func)
//		{}
////---------------------------------------------------------------------
//inline void ShiftFunctor::operator()(size_t& _num)
//{
//	m_func(_num, m_jump, m_shift);
//}
////---------------------------------------------------------------------




