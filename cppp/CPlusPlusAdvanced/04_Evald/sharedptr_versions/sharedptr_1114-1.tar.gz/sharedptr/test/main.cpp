/***************************************************************************
	Author: Stav Ofer
	Creation date:  		2013-11-08    
	Last modified date:		2013-11-10
	Description: 	Shared pointer test - prints only errors
****************************************************************************/

#include <string>
#include <iostream>
#include <sstream>

#include "sharedptr.h"

using namespace std;
using namespace m7;


//-----------------------------------------------------------------------//
// 	Base & derived class for test
//-----------------------------------------------------------------------//
class Person
{
public:
	explicit Person(const string _name, int _age) : m_name(_name), m_age(_age) {}
	virtual ~Person() {};
	
	const string& GetName() const { return m_name; }
	const int GetAge() const { return m_age; }
	
private:
	string m_name;
	int m_age;
};


class Student: public Person
{
public:
	explicit Student(const string _name, int _age, int _grade) : Person(_name, _age), m_grade(_grade) {}
	
	const int GetGrade() const { return m_grade; }
	
private:
	int m_grade;
};



const int NUM = 4;

const string names[NUM] = { "Aaa", "Bbbb", "Cc", "Ddd"};
const int ages[NUM] = {40, 25, 20, 60};
const int grades[NUM] = {85, 70, 90, 75};

//-----------------------------------------------------------------------//
// 									MAIN
//-----------------------------------------------------------------------//
int main()
{
	Person* per1 = new Person(names[0], ages[0]);
	
	string tempName;
	int tempAge;
	
	// assign person to sharePtr
	SharedPtr<Person> ptr1(per1);
	
	// not shared
	if( ptr1.IsShared() ) {
		cerr << "line " << __LINE__ << endl;
	}
	
	// operators
	tempName = ptr1->GetName();
	if( tempName != names[0] ) {
		cerr << "line " << __LINE__ << endl;
	}
	tempAge = (*ptr1).GetAge();
	if( tempAge != ages[0] ) {
		cerr << "line " << __LINE__ << endl;
	}
	
	// new SharedPtr, copy-constructed
	SharedPtr<Person> ptr2(ptr1);
	
	// shared
	if( !ptr1.IsShared() ) {
		cerr << "line " << __LINE__ << endl;
	}
	if( !ptr2.IsShared() ) {
		cerr << "line " << __LINE__ << endl;
	}
	
	// operators on other SharedPtr
	tempName = ptr2->GetName();
	if( tempName != names[0] ) {
		cerr << "line " << __LINE__ << endl;
	}
	tempAge = (*ptr2).GetAge();
	if( tempAge != ages[0] ) {
		cerr << "line " << __LINE__ << endl;
	}
	
	// new person & new SharedPtr
	Person* per2 = new Person(names[1], ages[1]);
	SharedPtr<Person> ptr3(per2);
	
	// not shared
	if( ptr3.IsShared() ) {
		cerr << "line " << __LINE__ << endl;
	}
	
	// assignment
	ptr1 = ptr3;
	
	// now ptr1,3 are shared, ptr2 not
	if( !ptr1.IsShared() ) {
		cerr << "line " << __LINE__ << endl;
	}
	if( ptr2.IsShared() ) {
		cerr << "line " << __LINE__ << endl;
	}
	if( !ptr3.IsShared() ) {
		cerr << "line " << __LINE__ << endl;
	}
	
	// ptr1 now points to per2
	tempName = ptr1->GetName();
	if( tempName != names[1] ) {
		cerr << "line " << __LINE__ << endl;
	}
	tempAge = (*ptr1).GetAge();
	if( tempAge != ages[1] ) {
		cerr << "line " << __LINE__ << endl;
	}
	
	// new person of derived class, & new ptr
	Person* stu1 = new Student(names[2], ages[2], grades[2]);
	SharedPtr<Person> ptr4(stu1);
	
	// not shared
	if( ptr4.IsShared() ) {
		cerr << "line " << __LINE__ << endl;
	}
	
	// operators
	tempName = ptr4->GetName();
	if( tempName != names[2] ) {
		cerr << "line " << __LINE__ << endl;
	}
	tempAge = (*ptr4).GetAge();
	if( tempAge != ages[2] ) {
		cerr << "line " << __LINE__ << endl;
	}
	
	// assignment b/w pointer to Person & Student
	ptr2 = ptr4;
	// shared
	if( !ptr2.IsShared() ) {
		cerr << "line " << __LINE__ << endl;
	}
	if( !ptr4.IsShared() ) {
		cerr << "line " << __LINE__ << endl;
	}
	
	// new student & new ptr
	Student* stu2 = new Student(names[3], ages[3], grades[3]);
	SharedPtr<Student> ptr5(stu2);
	
	// not shared
	if( ptr5.IsShared() ) {
		cerr << "line " << __LINE__ << endl;
	}
	
	// operators
	tempName = ptr5->GetName();
	if( tempName != names[3] ) {
		cerr << "line " << __LINE__ << endl;
	}
	tempAge = (*ptr5).GetAge();
	if( tempAge != ages[3] ) {
		cerr << "line " << __LINE__ << endl;
	}
	int tempGrade = ptr5->GetGrade();
	if( tempGrade != grades[3] ) {
		cerr << "line " << __LINE__ << endl;
	}
	
	return 0;
}



//######################################################################//
//---------------------------------------------------------------------
