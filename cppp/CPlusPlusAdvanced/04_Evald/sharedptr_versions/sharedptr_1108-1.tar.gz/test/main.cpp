/***************************************************************************
	Author: Stav Ofer
	Creation date:  		2013-11-08    
	Last modified date:		2013-11-08
	Description: 	Shared pointer test
****************************************************************************/

#include <vector>
#include <string>
#include <iostream>

#include "sharedptr.h"

using namespace std;
using namespace m7;

typedef vector<string> vec;

int main()
{
	vec* myVec = new vec;	// object of shared ptr
	
	SharedPtr<vec> p1(myVec);
	
	cout << "p1: " << p1.IsShared() << endl;
	
	SharedPtr<vec> p2(p1);
	cout << "p1: " << p1.IsShared() << endl;
	cout << "p2: " << p2.IsShared() << endl;
	
	
	
	vec* vec2 = new vec;
	
	SharedPtr<vec> p3(vec2);
	cout << "p3: " << p3.IsShared() << endl;
		
	p1 = p3;
	cout << "p1: " << p1.IsShared() << endl;
	cout << "p2: " << p2.IsShared() << endl;
	cout << "p3: " << p3.IsShared() << endl;
	
	///// *** test with base & derived classes
	
	
	return 0;
}



//######################################################################//
//---------------------------------------------------------------------
